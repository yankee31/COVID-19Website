<template>
  <div class="hello">
    <p style="font-size:32px;text-align:center;">{{ msg }}</p>
    <div class="update">
    <center>
    <div class="soft">
      <h2>Confirmed Cases</h2>
      <h1 style="color:#5BC0DE">{{list.cases.toLocaleString()}}</h1>
    </div>

    <div class="soft">
      <h2>Active Cases</h2>
      <h1 style="color:#F0AD4E">{{list.active.toLocaleString()}}</h1>

    </div>
    <div class="soft">
      <h2>Recovered Cases</h2>
      <h1 style="color:#22BB33">{{list.recovered.toLocaleString()}}</h1>

    </div>
    <div class="soft">
      <h2>Deceased Cases</h2>
      <h1 style="color:#BB2124">{{list.deaths.toLocaleString()}}</h1>

    </div>
    </center>
    </div>
    <div class="today">
      <div class="soft">
      <h2>Critical Cases</h2>
      <h1 style="color:#BB2124">{{list.critical.toLocaleString()}}</h1>
    </div>
    <div class="soft">
      <h2>Total Tested</h2>
      
      <h1 style="color:#BB2124">{{list.totalTests.toLocaleString()}}</h1>
    </div>
    <div class="soft">
      <h2>New active Cases</h2>
      <h1 style="color:#BB2124">{{list.todayCases.toLocaleString()}}</h1>
    </div>
    <div class="soft">
      <h2>New Deaths Cases</h2>
      <h1 style="color:#BB2124">{{list.todayDeaths.toLocaleString()}}</h1>
    </div>
      
    </div>

  </div>
</template>

<script>
import Vue from 'vue';
import axios from 'axios';
import VueAxios from 'vue-axios';
Vue.use(VueAxios,axios)
export default {
  name: 'CovidStatus',
  props: {
    msg: String
  },
  data(){
    return {list:undefined}
  },

  mounted(){
    Vue.axios.get('https://coronavirus-19-api.herokuapp.com/countries/Philippines')
    .then((res)=>{
      this.list = res.data;
      console.warn(res.data)
    })
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
.update{
  width: 100%;
}
.today{
  width: 100%;
}
.soft{
  float:left;
  padding-top: 24px;
  margin-left: 42px;
  margin-bottom: 24px;
  text-align: center;
  height: 200px;
  width: 20%;
  border-radius: 50px;
background: #ffffff;
box-shadow:  20px 20px 60px #d9d9d9, 
             -20px -20px 60px #ffffff;
}
h1:hover{
  transform: scale(1.6);

  transition: transform 1s, filter 2s ease-in-out;
}
</style>
