<template>
  <div class="hi">
    <h1>Health Information</h1>
	<h5>COVID-19 affects different people in different ways. Most infected people will develop mild to moderate illness and recover without hospitalization.
	</h5>
	<h4>Most common symptoms</h4>
	<ul>
	<li>fever</li>
	<li>dry cough</li>
	<li>tiredness</li>
	</ul>
	<h4>Less common symptoms:</h4>
	<ul>
	<li>aches and pains</li>	
	<li>sore throat</li>	
	<li>diarrhoea</li>	
	<li>conjunctivitis</li>	
	<li>headache</li>	
	<li>loss of taste or smell</li>	
	<li>a rash on skin, or discolouration of fingers or toes</li>	
	</ul>
	<h4>Serious symptoms:</h4>
	<ul>
	<li>difficulty breathing or shortness of breath</li>
	<li>chest pain or pressure</li>
	<li>loss of speech or movement</li>
	</ul>
  </div>
</template>
<style scoped>
	.hi{
		font-family: 'Monda', sans-serif;
		width: 75%;
		padding: 24px;
		margin-top: 28px;
		margin-left: 14%;
		border-radius: 50px;
		background: #ffffff;
box-shadow:  20px 20px 60px #d9d9d9, 
             -20px -20px 60px #ffffff;
	}
</style>
