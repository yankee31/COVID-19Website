<template>
  <div class="home">
    <CovidStatus msg="Covid Update"/>
  </div>
</template>

<script>
// @ is an alias to /src
import CovidStatus from '@/components/CovidStatus.vue'

export default {
  name: 'Home',
  components: {
    CovidStatus
  }
};
</script>

