<template>
  <div class="about">
    <p>This website will let you know the updates of covid status and also it will give an information about Coronavirus</p>
  </div>
</template>
<style scoped>
	p{
		font-size: 56px;
		font-family: 'Monda', sans-serif;
	}
	.about{
		width: 75%;
		padding: 24px;
		margin-top: 28px;
		margin-left: 14%;
		border-radius: 50px;
		background: #ffffff;
box-shadow:  20px 20px 60px #d9d9d9, 
             -20px -20px 60px #ffffff;
	}
</style>
