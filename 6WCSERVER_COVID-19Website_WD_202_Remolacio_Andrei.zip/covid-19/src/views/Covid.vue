<template>
  <div class="co">
    <h1>Q&A on coronaviruses (COVID-19)</h1>
    <h3>What is COVID-19</h3>
    <p>COVID-19 is the infectious disease caused by the most recently discovered coronavirus. This new virus and disease were unknown before the outbreak began in Wuhan, China, in December 2019. COVID-19 is now a pandemic affecting many countries globally.</p>
    <h3>What are the symptoms of COVID-19</h3>
    <p>The most common symptoms of COVID-19 are fever, dry cough, and tiredness. Other symptoms that are less common and may affect some patients include aches and pains, nasal congestion, headache, conjunctivitis, sore throat, diarrhea, loss of taste or smell or a rash on skin or discoloration of fingers or toes. These symptoms are usually mild and begin gradually. Some people become infected but only have very mild symptoms.

Most people (about 80%) recover from the disease without needing hospital treatment. Around 1 out of every 5 people who gets COVID-19 becomes seriously ill and develops difficulty breathing. Older people, and those with underlying medical problems like high blood pressure, heart and lung problems, diabetes, or cancer, are at higher risk of developing serious illness.  However, anyone can catch COVID-19 and become seriously ill.  People of all ages who experience fever and/or  cough associated withdifficulty breathing/shortness of breath, chest pain/pressure, or loss of speech or movement should seek medical attention immediately. If possible, it is recommended to call the health care provider or facility first, so the patient can be directed to the right clinic.</p>
    <h3>How does COVID-19 spread</h3>
    <p>People can catch COVID-19 from others who have the virus. The disease spreads primarily from person to person through small droplets from the nose or mouth, which are expelled when a person with COVID-19 coughs, sneezes, or speaks. These droplets are relatively heavy, do not travel far and quickly sink to the ground. People can catch COVID-19 if they breathe in these droplets from a person infected with the virus.  This is why it is important to stay at least 1 meter) away from others. These droplets can land on objects and surfaces around the person such as tables, doorknobs and handrails.  People can become infected by touching these objects or surfaces, then touching their eyes, nose or mouth.  This is why it is important to wash your hands regularly with soap and water or clean with alcohol-based hand rub.

WHO is assessing ongoing research on the ways that COVID-19 is spread and will continue to share updated findings.    </p>
    <h3>How can we protect others and ourselvesif we don't know who is infected</h3>
    <p>Practicing hand and respiratory hygiene is important at ALL times and is the best way to protect others and yourself.

When possible maintain at least a 1 meter distance between yourself and others. This is especially important if you are standing by someone who is coughing or sneezing.  Since some infected persons may not yet be exhibiting symptoms or their symptoms may be mild, maintaining a physical distance with everyone is a good idea if you are in an area where COVID-19 is circulating. </p>
    <h3></h3>
    <p></p>
  </div>
</template>
<style scoped>
	.co{
		width: 75%;
		padding: 5px;
		margin-top: 28px;
		margin-left: 14%;
		border-radius: 50px;
		background: #ffffff;
box-shadow:  20px 20px 60px #d9d9d9, 
             -20px -20px 60px #ffffff;
	}
	h1,h3,p{
		padding-left: 15px;
		padding-right: 15px;
	}
</style>